# DroneForce BVLOS Fleet Management Platform

A full BVLOS fleet management platform built for the interview demo. Multi-page, zero backend, works entirely in the browser.

## Live Demo
Click "Try the demo" on the login page — no account needed.

## Pages

| Page | Description |
|------|-------------|
| `index.html` | Login & org registration |
| `dashboard.html` | Fleet overview, alerts, activity feed |
| `registry.html` | Register & manage drones from 8+ manufacturers |
| `tracking.html` | Live GPS tracking, telemetry, factor analysis |
| `messages.html` | AES-256-GCM encrypted team & drone messaging |

## GitHub Pages Deployment

1. Create a new repo on github.com
2. Upload **all 8 files** (drag & drop in the GitHub UI)
3. Settings → Pages → Source: `main` branch, `/ (root)` → Save
4. Your URL: `https://yourusername.github.io/repo-name`

## Key Features

**Drone Registry** — 8 real manufacturers, full spec DB (battery, payload, speed, sensors), NDAA compliance tracking, FAA reg numbers, Remote ID modes

**Live Tracking** — Canvas map with real-time simulated GPS, wind/temp/humidity/pressure telemetry, motor temps, BVLOS Part 108 compliance checklist, Starlink mesh visualization

**Secure Messaging** — AES-256-GCM via Web Crypto API, HMAC-SHA256 integrity, per-message 96-bit IV, drone autopilot auto-feed, channel management

**Crypto stack:** `crypto.subtle` (Web Crypto API) — same standard as Signal/WhatsApp web. Key generated per session, encrypted-at-rest in localStorage.
