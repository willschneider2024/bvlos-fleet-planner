/* ═══════════════════════════════════════════════
   DRONEFORCE PLATFORM — CORE JS
   State, crypto, models, utilities
   ═══════════════════════════════════════════════ */

'use strict';

// ─── CRYPTO ENGINE (Web Crypto API — AES-GCM 256-bit) ───
const DFCrypto = {
  async generateKey() {
    return await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
  },

  async exportKey(key) {
    const raw = await crypto.subtle.exportKey('raw', key);
    return btoa(String.fromCharCode(...new Uint8Array(raw)));
  },

  async importKey(b64) {
    const raw = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
    return await crypto.subtle.importKey('raw', raw, { name: 'AES-GCM' }, true, ['encrypt', 'decrypt']);
  },

  async encrypt(text, key) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoded = new TextEncoder().encode(text);
    const cipher = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, encoded);
    const combined = new Uint8Array(iv.byteLength + cipher.byteLength);
    combined.set(iv, 0);
    combined.set(new Uint8Array(cipher), iv.byteLength);
    return btoa(String.fromCharCode(...combined));
  },

  async decrypt(b64, key) {
    try {
      const combined = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
      const iv = combined.slice(0, 12);
      const cipher = combined.slice(12);
      const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, cipher);
      return new TextDecoder().decode(plain);
    } catch {
      return '[DECRYPTION FAILED]';
    }
  },

  // HMAC-SHA256 for message integrity
  async sign(text, key) {
    const hmacKey = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(await this.exportKey(key)),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', hmacKey, new TextEncoder().encode(text));
    return btoa(String.fromCharCode(...new Uint8Array(sig))).slice(0, 16);
  },

  // Simple hash for IDs
  async hash(str) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('').slice(0, 12);
  }
};

// ─── DATA STORE (localStorage-backed) ───
const Store = {
  get(key, def = null) {
    try { return JSON.parse(localStorage.getItem('df_' + key)) ?? def; } catch { return def; }
  },
  set(key, val) {
    try { localStorage.setItem('df_' + key, JSON.stringify(val)); } catch {}
  },
  del(key) { localStorage.removeItem('df_' + key); },
  clear() {
    Object.keys(localStorage)
      .filter(k => k.startsWith('df_'))
      .forEach(k => localStorage.removeItem(k));
  }
};

// ─── DRONE SPECS DATABASE ───
const DRONE_SPECS = {
  // Manufacturer → models
  skydio: {
    name: 'Skydio',
    country: 'US',
    ndaa: true,
    models: {
      x10:  { name:'X10',      type:'quad',  color:'#00e5a0', icon:'⬡', battery:5200,  voltage:22.2, basePower:165, maxPayload:2.3,  maxSpeed:18, range:7,   weight:1.8,  sensors:['RGB 4K','Thermal','Depth'] },
      x2d:  { name:'X2D',      type:'quad',  color:'#00c48a', icon:'⬡', battery:4400,  voltage:22.2, basePower:140, maxPayload:0,    maxSpeed:16, range:5,   weight:0.8,  sensors:['RGB 4K','Depth'] },
      r1:   { name:'R1 (Autonomous)',type:'quad',color:'#10d98a',icon:'⬡',battery:6000,voltage:22.2,basePower:180,maxPayload:0,maxSpeed:20,range:8,weight:2.2,sensors:['RGB 12MP','Obstacle avoidance'] },
    }
  },
  freefly: {
    name: 'Freefly Systems',
    country: 'US',
    ndaa: true,
    models: {
      alta_x:  { name:'Alta X',    type:'octo',  color:'#3b82f6', icon:'✦', battery:16000, voltage:44.4, basePower:480, maxPayload:15.0, maxSpeed:14, range:4,   weight:6.2,  sensors:['Payload-dependent'] },
      astro:   { name:'Astro',     type:'quad',  color:'#60a5fa', icon:'⊕', battery:7000,  voltage:44.4, basePower:220, maxPayload:3.5,  maxSpeed:16, range:6,   weight:2.9,  sensors:['MoSys Mapping','RGB 4K'] },
    }
  },
  inspired: {
    name: 'Inspired Flight',
    country: 'US',
    ndaa: true,
    models: {
      if750i: { name:'IF750i',    type:'hex',   color:'#a78bfa', icon:'◉', battery:6000,  voltage:22.2, basePower:200, maxPayload:3.5,  maxSpeed:16, range:5,   weight:2.4,  sensors:['RGB','Thermal','LiDAR-optional'] },
      if800x: { name:'IF800X',   type:'octo',  color:'#7c3aed', icon:'◈', battery:22000, voltage:44.4, basePower:600, maxPayload:20.0, maxSpeed:12, range:3,   weight:8.5,  sensors:['LiDAR','RGB','Thermal'] },
    }
  },
  zipline: {
    name: 'Zipline',
    country: 'US',
    ndaa: true,
    models: {
      p2:   { name:'Platform 2', type:'fixed', color:'#f97316', icon:'▷', battery:8000,  voltage:44.4, basePower:120, maxPayload:1.8,  maxSpeed:38, range:80,  weight:8.0,  sensors:['Autopilot','GPS RTK','Barometer'] },
    }
  },
  parrot: {
    name: 'Parrot',
    country: 'FR',
    ndaa: false,
    models: {
      anafi_ai:  { name:'ANAFI Ai',  type:'quad',  color:'#38bdf8', icon:'◇', battery:3400,  voltage:11.1, basePower:78,  maxPayload:0.5,  maxSpeed:15, range:4,   weight:0.9,  sensors:['48MP','4K HDR','Thermal-optional'] },
      anafi_usa: { name:'ANAFI USA', type:'quad',  color:'#0ea5e9', icon:'◇', battery:4500,  voltage:14.8, basePower:100, maxPayload:0,    maxSpeed:15, range:5,   weight:1.1,  sensors:['32x zoom','Thermal','FLIR'] },
    }
  },
  wingtra: {
    name: 'WingtraOne',
    country: 'CH',
    ndaa: false,
    models: {
      gen2: { name:'GEN II',    type:'vtol',  color:'#fbbf24', icon:'⊡', battery:9000,  voltage:44.4, basePower:200, maxPayload:0.8,  maxSpeed:20, range:60,  weight:3.7,  sensors:['Sony RX1R II','LiDAR-optional'] },
    }
  },
  shield_ai: {
    name: 'Shield AI',
    country: 'US',
    ndaa: true,
    models: {
      nova2: { name:'Nova 2',    type:'quad',  color:'#ef4444', icon:'⊞', battery:4800,  voltage:22.2, basePower:185, maxPayload:2.0,  maxSpeed:20, range:5,   weight:2.3,  sensors:['Intel RealSense D455','NavStack AI'] },
    }
  },
  custom: {
    name: 'Custom / Open',
    country: 'XX',
    ndaa: false,
    models: {
      quad:  { name:'Quadrotor', type:'quad',  color:'#94a3b8', icon:'⊞', battery:5000,  voltage:22.2, basePower:180, maxPayload:5.0,  maxSpeed:15, range:5,   weight:3.0,  sensors:['Configurable'] },
      fixed: { name:'Fixed-Wing',type:'fixed', color:'#64748b', icon:'▷', battery:8000,  voltage:44.4, basePower:110, maxPayload:3.0,  maxSpeed:35, range:40,  weight:4.0,  sensors:['Configurable'] },
      vtol:  { name:'VTOL',      type:'vtol',  color:'#475569', icon:'⊙', battery:10000, voltage:44.4, basePower:200, maxPayload:7.0,  maxSpeed:20, range:25,  weight:5.0,  sensors:['Configurable'] },
    }
  }
};

const LINK_SPECS = {
  starlink:          { name:'Starlink',          latency:28,  bandwidth:287, color:'#8b5cf6', reliable:0.98,  encryption:'AES-256-GCM' },
  starlink_priority: { name:'Starlink Priority', latency:18,  bandwidth:500, color:'#a78bfa', reliable:0.995, encryption:'AES-256-GCM' },
  lte_5g:            { name:'5G LTE',            latency:15,  bandwidth:150, color:'#3b82f6', reliable:0.92,  encryption:'TLS 1.3' },
  mesh_rf:           { name:'Mesh RF 900MHz',    latency:5,   bandwidth:1,   color:'#00e5a0', reliable:0.85,  encryption:'AES-128-CCM' },
  iridium:           { name:'Iridium Certus',    latency:450, bandwidth:0.7, color:'#fbbf24', reliable:0.99,  encryption:'AES-256-GCM' },
  mavsdk_local:      { name:'MAVLink Local',     latency:2,   bandwidth:10,  color:'#94a3b8', reliable:0.99,  encryption:'None (local)' },
};

// ─── AUTH ───
const Auth = {
  currentUser: null,

  init() {
    const saved = Store.get('session');
    if (saved && saved.expires > Date.now()) {
      this.currentUser = saved.user;
      return true;
    }
    return false;
  },

  login(email, password, orgCode) {
    // Demo: any valid-looking credentials work; real app would hit an API
    if (!email || !password || password.length < 6) return false;
    const orgs = Store.get('orgs', {});
    let org = Object.values(orgs).find(o => o.code === orgCode.toUpperCase());
    if (!org && orgCode) {
      // Auto-create org on first login with code
      const orgId = 'org_' + Math.random().toString(36).slice(2, 10);
      org = { id: orgId, code: orgCode.toUpperCase(), name: orgCode + ' Operations', plan: 'pro', droneIds: [] };
      orgs[orgId] = org;
      Store.set('orgs', orgs);
    }
    const userId = 'usr_' + Math.random().toString(36).slice(2, 10);
    const user = {
      id: userId,
      email,
      name: email.split('@')[0].replace(/[._]/g,' ').replace(/\b\w/g,c=>c.toUpperCase()),
      role: 'operator',
      orgId: org?.id || null,
      orgCode: orgCode?.toUpperCase() || null,
      createdAt: Date.now()
    };
    this.currentUser = user;
    Store.set('session', { user, expires: Date.now() + 8 * 3600 * 1000 });
    return true;
  },

  logout() {
    this.currentUser = null;
    Store.del('session');
    window.location.href = 'index.html';
  },

  get org() {
    if (!this.currentUser?.orgId) return null;
    const orgs = Store.get('orgs', {});
    return orgs[this.currentUser.orgId] || null;
  },

  requireAuth() {
    if (!this.init()) { window.location.href = 'index.html'; return false; }
    return true;
  }
};

// ─── DRONE REGISTRY ───
const Registry = {
  getAll() {
    const all = Store.get('drones', {});
    const user = Auth.currentUser;
    if (!user) return [];
    // Filter to user's org
    return Object.values(all).filter(d => d.orgId === user.orgId);
  },

  get(id) {
    const all = Store.get('drones', {});
    return all[id] || null;
  },

  register(data) {
    const all = Store.get('drones', {});
    const id = 'df_' + crypto.randomUUID().slice(0,8).toUpperCase();
    const drone = {
      id,
      ...data,
      orgId: Auth.currentUser.orgId,
      registeredBy: Auth.currentUser.id,
      registeredAt: Date.now(),
      status: 'grounded',
      // Simulated telemetry seed
      telemetry: Registry._seedTelemetry(data),
    };
    all[id] = drone;
    Store.set('drones', all);
    return drone;
  },

  update(id, patch) {
    const all = Store.get('drones', {});
    if (!all[id]) return false;
    all[id] = { ...all[id], ...patch, updatedAt: Date.now() };
    Store.set('drones', all);
    return all[id];
  },

  delete(id) {
    const all = Store.get('drones', {});
    delete all[id];
    Store.set('drones', all);
  },

  _seedTelemetry(data) {
    return {
      lat: 37.4419 + (Math.random() - 0.5) * 0.05,
      lng: -122.1430 + (Math.random() - 0.5) * 0.05,
      alt: 0,
      heading: Math.round(Math.random() * 360),
      speed: 0,
      battery: 85 + Math.round(Math.random() * 15),
      signalStrength: 70 + Math.round(Math.random() * 30),
      satellites: 12 + Math.round(Math.random() * 6),
      temperature: 18 + Math.round(Math.random() * 12),
      humidity: 40 + Math.round(Math.random() * 40),
      pressure: 1013 + Math.round(Math.random() * 10),
      windSpeed: Math.round(Math.random() * 15),
      windDir: Math.round(Math.random() * 360),
      vibration: (Math.random() * 0.5).toFixed(2),
      motorTemps: [42, 44, 41, 43].map(t => t + Math.round(Math.random() * 8)),
      flightTime: 0,
      distanceTraveled: 0,
      lastSeen: Date.now(),
      linkLatency: 25 + Math.round(Math.random() * 30),
    };
  }
};

// ─── TELEMETRY SIMULATOR ───
const TelemetrySim = {
  intervals: {},

  start(droneId, onUpdate) {
    if (this.intervals[droneId]) return;
    const drone = Registry.get(droneId);
    if (!drone) return;

    let tel = { ...drone.telemetry };
    let tick = 0;

    this.intervals[droneId] = setInterval(() => {
      tick++;
      // Simulate realistic movement and sensor changes
      if (drone.status === 'flying') {
        const heading = tel.heading * Math.PI / 180;
        tel.lat += Math.sin(heading) * 0.00002 * (tel.speed / 15);
        tel.lng += Math.cos(heading) * 0.00002 * (tel.speed / 15);
        tel.heading = (tel.heading + (Math.random() - 0.5) * 8) % 360;
        if (tel.heading < 0) tel.heading += 360;
        tel.alt = Math.max(0, tel.alt + (Math.random() - 0.48) * 3);
        tel.speed = Math.max(0, Math.min(drone.spec?.maxSpeed || 15, tel.speed + (Math.random() - 0.5) * 2));
        tel.battery = Math.max(0, tel.battery - 0.03);
        tel.flightTime += 1;
        tel.distanceTraveled += tel.speed * 1; // meters
      }
      // Environmental sim
      tel.windSpeed = Math.max(0, tel.windSpeed + (Math.random() - 0.5) * 1.5);
      tel.windDir = (tel.windDir + (Math.random() - 0.5) * 10) % 360;
      tel.temperature += (Math.random() - 0.5) * 0.3;
      tel.humidity = Math.max(20, Math.min(95, tel.humidity + (Math.random() - 0.5) * 1));
      tel.pressure += (Math.random() - 0.5) * 0.5;
      tel.signalStrength = Math.max(20, Math.min(100, tel.signalStrength + (Math.random() - 0.5) * 4));
      tel.satellites = Math.max(6, Math.min(20, tel.satellites + (Math.random() < 0.1 ? (Math.random() < 0.5 ? 1 : -1) : 0)));
      tel.linkLatency = Math.max(10, tel.linkLatency + (Math.random() - 0.5) * 8);
      tel.vibration = Math.max(0, Math.min(3, parseFloat(tel.vibration) + (Math.random() - 0.5) * 0.1)).toFixed(2);
      tel.motorTemps = tel.motorTemps.map(t => Math.max(20, Math.min(85, t + (Math.random() - 0.5) * 1.5)));
      tel.lastSeen = Date.now();

      // Persist every 5 ticks
      if (tick % 5 === 0) {
        Registry.update(droneId, { telemetry: tel });
      }
      if (onUpdate) onUpdate({ ...tel });
    }, 1000);
  },

  stop(droneId) {
    if (this.intervals[droneId]) {
      clearInterval(this.intervals[droneId]);
      delete this.intervals[droneId];
    }
  },

  stopAll() {
    Object.keys(this.intervals).forEach(id => this.stop(id));
  }
};

// ─── SECURE MESSAGING ───
const SecureMessaging = {
  _key: null,

  async init() {
    const stored = Store.get('msgKey');
    if (stored) {
      try { this._key = await DFCrypto.importKey(stored); return; } catch {}
    }
    this._key = await DFCrypto.generateKey();
    Store.set('msgKey', await DFCrypto.exportKey(this._key));
  },

  async send(channelId, text, senderName, type = 'text') {
    if (!this._key) await this.init();
    const plaintext = JSON.stringify({ text, type, sender: senderName, ts: Date.now() });
    const encrypted = await DFCrypto.encrypt(plaintext, this._key);
    const sig = await DFCrypto.sign(plaintext, this._key);
    const msg = {
      id: 'msg_' + crypto.randomUUID().slice(0, 8),
      channelId,
      encrypted,
      sig,
      senderName,
      ts: Date.now(),
      type,
    };
    const msgs = Store.get('messages', {});
    if (!msgs[channelId]) msgs[channelId] = [];
    msgs[channelId].push(msg);
    // Keep last 200 per channel
    if (msgs[channelId].length > 200) msgs[channelId] = msgs[channelId].slice(-200);
    Store.set('messages', msgs);
    return msg;
  },

  async getMessages(channelId) {
    if (!this._key) await this.init();
    const msgs = Store.get('messages', {});
    const raw = msgs[channelId] || [];
    return Promise.all(raw.map(async m => {
      try {
        const plain = await DFCrypto.decrypt(m.encrypted, this._key);
        const data = JSON.parse(plain);
        return { ...m, ...data, decrypted: true };
      } catch {
        return { ...m, text: '[Cannot decrypt]', decrypted: false };
      }
    }));
  },

  getChannels() {
    return Store.get('channels', [
      { id: 'ch_ops',     name: 'Operations',    icon: '🏗',  drone: null },
      { id: 'ch_fleet',   name: 'Fleet Control', icon: '🚁',  drone: null },
      { id: 'ch_alerts',  name: 'Alerts & ATC',  icon: '⚠',   drone: null },
    ]);
  },

  addChannel(name, icon = '💬', droneId = null) {
    const channels = this.getChannels();
    const ch = { id: 'ch_' + Math.random().toString(36).slice(2,8), name, icon, drone: droneId };
    channels.push(ch);
    Store.set('channels', channels);
    return ch;
  }
};

// ─── TOAST UTILITY ───
const Toast = {
  container: null,
  init() {
    if (!this.container) {
      this.container = document.createElement('div');
      this.container.className = 'toast-container';
      document.body.appendChild(this.container);
    }
  },
  show(msg, type = 'info', duration = 3000) {
    this.init();
    const el = document.createElement('div');
    const icons = { success: '✓', error: '✕', warn: '⚠', info: 'ℹ' };
    el.className = `toast toast-${type === 'success' ? 'success' : type === 'error' ? 'error' : 'warn'}`;
    el.innerHTML = `<span style="color:${type==='success'?'var(--accent)':type==='error'?'var(--danger)':'var(--warn)'}">${icons[type]||'ℹ'}</span> ${msg}`;
    this.container.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity 0.3s'; setTimeout(() => el.remove(), 300); }, duration);
  }
};

// ─── MODAL UTILITY ───
const Modal = {
  show(title, bodyHTML, footerHTML = '', onClose = null) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal">
        <div class="modal-header">
          <span class="modal-title">${title}</span>
          <span class="modal-close" id="modalClose">×</span>
        </div>
        <div class="modal-body">${bodyHTML}</div>
        ${footerHTML ? `<div class="modal-footer">${footerHTML}</div>` : ''}
      </div>`;
    document.body.appendChild(overlay);
    const close = () => { overlay.remove(); if (onClose) onClose(); };
    overlay.querySelector('#modalClose').onclick = close;
    overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
    return { overlay, close };
  }
};

// ─── FORMATTING HELPERS ───
const Fmt = {
  battery(pct) {
    if (pct > 60) return `<span class="accent-text">${pct.toFixed(0)}%</span>`;
    if (pct > 25) return `<span class="warn-text">${pct.toFixed(0)}%</span>`;
    return `<span class="danger-text">${pct.toFixed(0)}%</span>`;
  },
  status(s) {
    const map = {
      flying:   '<span class="badge badge-amber">FLYING</span>',
      grounded: '<span class="badge badge-gray">GROUNDED</span>',
      charging: '<span class="badge badge-blue">CHARGING</span>',
      error:    '<span class="badge badge-red">ERROR</span>',
      maintenance: '<span class="badge badge-purple">MAINT.</span>',
    };
    return map[s] || `<span class="badge badge-gray">${s.toUpperCase()}</span>`;
  },
  time(ts) {
    const d = new Date(ts);
    return d.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
  },
  date(ts) {
    return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  },
  duration(seconds) {
    const h = Math.floor(seconds / 3600), m = Math.floor((seconds % 3600) / 60), s = seconds % 60;
    if (h) return `${h}h ${m}m`;
    if (m) return `${m}m ${s}s`;
    return `${s}s`;
  },
  distance(meters) {
    return meters >= 1000 ? `${(meters/1000).toFixed(2)}km` : `${Math.round(meters)}m`;
  },
  wind(speed) {
    if (speed < 0.5) return 'Calm';
    if (speed < 5.5) return 'Light';
    if (speed < 10.7) return 'Moderate';
    if (speed < 17.2) return 'Strong';
    return 'Gale';
  },
  beaufort(ws) {
    if (ws < 0.5) return 0; if (ws < 1.5) return 1; if (ws < 3.3) return 2;
    if (ws < 5.5) return 3; if (ws < 7.9) return 4; if (ws < 10.7) return 5;
    if (ws < 13.8) return 6; return 7;
  },
  bearing(deg) {
    const dirs = ['N','NNE','NE','ENE','E','ESE','SE','SSE','S','SSW','SW','WSW','W','WNW','NW','NNW'];
    return dirs[Math.round(deg / 22.5) % 16];
  },
  latLng(lat, lng) {
    return `${lat.toFixed(5)}°N, ${Math.abs(lng).toFixed(5)}°W`;
  }
};

// ─── DEMO DATA SEEDER ───
const Seeder = {
  run() {
    if (Store.get('seeded')) return;

    // Seed an org
    const orgId = 'org_demo';
    const orgs = { [orgId]: { id: orgId, code: 'DEMO', name: 'Demo Operations LLC', plan: 'pro', droneIds: [] } };
    Store.set('orgs', orgs);

    // Seed a user session
    const user = { id: 'usr_demo', email: 'pilot@demo.com', name: 'Demo Pilot', role: 'operator', orgId, orgCode: 'DEMO' };
    Store.set('session', { user, expires: Date.now() + 8 * 3600 * 1000 });

    // Seed drones
    const droneDefs = [
      { mfr: 'skydio',    model: 'x10',    callsign: 'ALPHA-1', serial: 'SKY-2024-001', status: 'flying',    linkType: 'starlink' },
      { mfr: 'freefly',   model: 'alta_x', callsign: 'BRAVO-2', serial: 'FFL-2024-007', status: 'grounded',  linkType: 'starlink_priority' },
      { mfr: 'inspired',  model: 'if750i', callsign: 'CHARLIE-3',serial: 'IFL-2024-012', status: 'flying',   linkType: 'lte_5g' },
      { mfr: 'zipline',   model: 'p2',     callsign: 'DELTA-4',  serial: 'ZIP-2024-003', status: 'grounded',  linkType: 'starlink' },
      { mfr: 'shield_ai', model: 'nova2',  callsign: 'ECHO-5',   serial: 'SAI-2024-021', status: 'charging',  linkType: 'mesh_rf' },
    ];

    const allDrones = {};
    droneDefs.forEach(def => {
      const mfrSpec = DRONE_SPECS[def.mfr];
      const modelSpec = mfrSpec.models[def.model];
      const id = 'df_' + def.serial.slice(-4).padStart(8, '0').toUpperCase();
      const drone = {
        id,
        callsign: def.callsign,
        serial: def.serial,
        manufacturer: def.mfr,
        model: def.model,
        mfrName: mfrSpec.name,
        modelName: modelSpec.name,
        spec: modelSpec,
        ndaa: mfrSpec.ndaa,
        linkType: def.linkType,
        status: def.status,
        orgId,
        registeredBy: 'usr_demo',
        registeredAt: Date.now() - Math.random() * 30 * 86400000,
        notes: '',
        telemetry: Registry._seedTelemetry({ spec: modelSpec }),
        flightLog: [],
      };
      if (def.status === 'flying') {
        drone.telemetry.alt = 80 + Math.round(Math.random() * 200);
        drone.telemetry.speed = 8 + Math.round(Math.random() * 12);
        drone.telemetry.flightTime = Math.round(Math.random() * 1800);
      }
      allDrones[id] = drone;
    });
    Store.set('drones', allDrones);
    Store.set('seeded', true);
  }
};
