/* ═══════════════════════════════════════════════
   DRONEFORCE — SHARED SIDEBAR
   ═══════════════════════════════════════════════ */
function buildSidebar(activePage) {
  const user = Auth.currentUser || {};
  const org  = Auth.org || {};
  const initials = (user.name||'??').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();
  const drones = Registry.getAll();
  const flyingCount = drones.filter(d=>d.status==='flying').length;

  return `<aside class="sidebar">
    <div class="sidebar-logo">
      <div class="wordmark">DRONE<span>FORCE</span></div>
      <div class="tagline">BVLOS FLEET PLATFORM</div>
    </div>

    <div class="sidebar-section">
      <div class="sidebar-section-label">Main</div>
      <a class="nav-item ${activePage==='dashboard'?'active':''}" href="dashboard.html">
        <span class="nav-icon">▦</span> Dashboard
        ${flyingCount > 0 ? `<span class="nav-badge green">${flyingCount} up</span>` : ''}
      </a>
      <a class="nav-item ${activePage==='tracking'?'active':''}" href="tracking.html">
        <span class="nav-icon">◎</span> Live Tracking
      </a>
      <a class="nav-item ${activePage==='registry'?'active':''}" href="registry.html">
        <span class="nav-icon">⊞</span> Drone Registry
      </a>
      <a class="nav-item ${activePage==='planner'?'active':''}" href="planner.html">
        <span class="nav-icon">⊕</span> Route Planner
      </a>
    </div>

    <div class="sidebar-section">
      <div class="sidebar-section-label">Comms</div>
      <a class="nav-item ${activePage==='messages'?'active':''}" href="messages.html">
        <span class="nav-icon">🔒</span> Secure Messaging
      </a>
      <a class="nav-item ${activePage==='alerts'?'active':''}" href="dashboard.html">
        <span class="nav-icon">⚠</span> Alerts
      </a>
    </div>

    <div class="sidebar-section">
      <div class="sidebar-section-label">Org: ${org.code||'—'}</div>
      <div class="nav-item" style="cursor:default;font-size:11px;">
        <span class="nav-icon" style="color:var(--accent)">✓</span>
        <span style="color:var(--text3)">${org.name||'Personal'}</span>
      </div>
      <div class="nav-item" style="cursor:default;font-size:11px;">
        <span class="nav-icon" style="color:var(--purple)">◉</span>
        <span style="color:var(--text3)">Starlink Mesh</span>
        <span class="nav-badge green">LIVE</span>
      </div>
    </div>

    <div class="sidebar-bottom">
      <div class="user-chip">
        <div class="user-avatar">${initials}</div>
        <div>
          <div class="user-name">${user.name||'Pilot'}</div>
          <div class="user-role">${user.role||'operator'}</div>
        </div>
        <div class="user-logout" onclick="Auth.logout()" title="Sign out">⏻</div>
      </div>
    </div>
  </aside>`;
}
